import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EX3 {
    public static void main(String[] args) throws Exception {
        ReadText readText = new ReadText();

        String sMsgClara = readText.readTextString();
        byte[] bMsgClara = sMsgClara.getBytes("ISO-8859-1");

        try (BufferedWriter writerCifrada = new BufferedWriter(
               new FileWriter("Exercicio 3/texto_cifrada.txt"));

             BufferedWriter writerDecifrada = new BufferedWriter(
               new FileWriter("Exercicio 3/texto_decifrado.txt"))) {

            Impressora prn = new Impressora();

            // Criptografia Dummy
            CryptoDummy cdummy = new CryptoDummy();
            cdummy.geraChave(new File("Exercicio 3/chave.dummy"));
            cdummy.geraCifra(bMsgClara, new File("Exercicio 3/chave.dummy"));
            byte[] bMsgCifrada = cdummy.getTextoCifrado();
            byte[] bMsgDecifrada;

            writerCifrada.write(">>> Cifrando com o algoritmo Dummy...\n\n");
            writerCifrada.write("Mensagem Cifrada (Hexadecimal):\n");
            writerCifrada.write(prn.hexBytesToString(bMsgCifrada));
            writerCifrada.write("\n\n");
            writerCifrada.write("Mensagem Cifrada (String):\n");
            writerCifrada.write(new String(bMsgCifrada, "ISO-8859-1"));
            writerCifrada.write("\n\n");

            cdummy.geraDecifra(bMsgCifrada, new File("Exercicio 3/chave.dummy"));
            bMsgDecifrada = cdummy.getTextoDecifrado();

            writerDecifrada.write(">>> Decifrando com o algoritmo Dummy...\n\n");
            writerDecifrada.write("Mensagem Decifrada (Hexadecimal):\n");
            writerDecifrada.write(prn.hexBytesToString(bMsgDecifrada));
            writerDecifrada.write("\n\n");
            writerDecifrada.write("Mensagem Decifrada (String):\n");
            writerDecifrada.write(new String(bMsgDecifrada, "ISO-8859-1"));
            writerDecifrada.write("\n\n");

            // Criptografia AES
            CryptoAES caes = new CryptoAES();
            caes.geraChave(new File("Exercicio 3/chave.simetrica"));
            caes.geraCifra(bMsgClara, new File("Exercicio 3/chave.simetrica"));
            bMsgCifrada = caes.getTextoCifrado();

            writerCifrada.write(">>> Cifrando com o algoritmo AES...\n\n");
            writerCifrada.write("Mensagem Cifrada (Hexadecimal):\n");
            writerCifrada.write(prn.hexBytesToString(bMsgCifrada));
            writerCifrada.write("\n\n");
            writerCifrada.write("Mensagem Cifrada (String):\n");
            writerCifrada.write(new String(bMsgCifrada, "ISO-8859-1"));
            writerCifrada.write("\n\n");

            caes.geraDecifra(bMsgCifrada, new File("Exercicio 3/chave.simetrica"));
            bMsgDecifrada = caes.getTextoDecifrado();

            writerDecifrada.write(">>> Decifrando com o algoritmo AES...\n\n");
            writerDecifrada.write("Mensagem Decifrada (Hexadecimal):\n");
            writerDecifrada.write(prn.hexBytesToString(bMsgDecifrada));
            writerDecifrada.write("\n\n");
            writerDecifrada.write("Mensagem Decifrada (String):\n");
            writerDecifrada.write(new String(bMsgDecifrada, "ISO-8859-1"));
            writerDecifrada.write("\n\n");

            // Criptografia RSA
            CryptoRSA crsa = new CryptoRSA();
            crsa.geraParDeChaves(new File("Exercicio 3/chave.publica"), new File("Exercicio 3/chave.privada"));
            crsa.geraCifra(bMsgClara, new File("Exercicio 3/chave.publica"));
            bMsgCifrada = crsa.getTextoCifrado();

            writerCifrada.write(">>> Cifrando com o algoritmo RSA...\n\n");
            writerCifrada.write("Mensagem Cifrada (Hexadecimal):\n");
            writerCifrada.write(prn.hexBytesToString(bMsgCifrada));
            writerCifrada.write("\n\n");
            writerCifrada.write("Mensagem Cifrada (String):\n");
            writerCifrada.write(new String(bMsgCifrada, "ISO-8859-1"));
            writerCifrada.write("\n\n");

            crsa.geraDecifra(bMsgCifrada, new File("Exercicio 3/chave.privada"));
            bMsgDecifrada = crsa.getTextoDecifrado();

            writerDecifrada.write(">>> Decifrando com o algoritmo RSA...\n\n");
            writerDecifrada.write("Mensagem Decifrada (Hexadecimal):\n");
            writerDecifrada.write(prn.hexBytesToString(bMsgDecifrada));
            writerDecifrada.write("\n\n");
            writerDecifrada.write("Mensagem Decifrada (String):\n");
            writerDecifrada.write(new String(bMsgDecifrada, "ISO-8859-1"));
            writerDecifrada.write("\n\n");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
