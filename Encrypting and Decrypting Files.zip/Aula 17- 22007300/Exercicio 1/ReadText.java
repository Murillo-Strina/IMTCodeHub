import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner; 


public class ReadText {
    public String readTextString() {
    String data = "";
    try {
        File arquivoTexto = new File("Texto.txt");
        Scanner leitor = new Scanner(arquivoTexto);
        while (leitor.hasNextLine()) {
        data = leitor.nextLine();
        }
        leitor.close();
    } catch (FileNotFoundException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
    }
        return data;
    }
}

