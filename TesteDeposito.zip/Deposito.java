import java.util.ArrayList;

public class Deposito {
    private ArrayList<Caixa> caixas;

    public Deposito() {
        this.caixas = new ArrayList<>();
    }

    public void adicionarCaixa(Caixa caixa) {
        this.caixas.add(caixa);
    }

    public void removerCaixa(String dono) {
        this.caixas.removeIf(caixa -> caixa.getDono().equals(dono));
    }

    public int encontrarCaixa(String dono) {
        for (int i = 0; i < this.caixas.size(); i++) {
            if (this.caixas.get(i).getDono().equals(dono)) {
                return i;
            }
        }
        return -1;
    }

    public void mudarCorredorPosicao(String dono, String novoCorredor, int novaPosicao) {
        int index = encontrarCaixa(dono);
        if (index != -1) {
            Caixa caixa = this.caixas.get(index);
            caixa.setCorredor(novoCorredor);
            caixa.setPosicao(novaPosicao);
        } else {
            System.out.println("Caixa não encontrada.");
        }
    }

    public Caixa[] caixasPesadas(double pesoMinimo) {
        ArrayList<Caixa> caixasPesadas = new ArrayList<>();
        for (Caixa caixa : this.caixas) {
            if (caixa.getPeso() > pesoMinimo) {
                caixasPesadas.add(caixa);
            }
        }
        return caixasPesadas.toArray(new Caixa[0]);
    }
}
