import javax.swing.JOptionPane;

public class TesteDeposito {
    public static void main(String[] args) {
        Deposito deposito = new Deposito();
        int opcao;
        do {
            opcao = Integer.parseInt(JOptionPane.showInputDialog(
                    "Escolha uma opção:\n" +
                            "1. Adiciona caixa\n" +
                            "2. Remove caixa\n" +
                            "3. Procura caixa\n" +
                            "4. Muda caixa\n" +
                            "5. Lista mais pesadas que 10.0\n" +
                            "6. Sair"));

            switch (opcao) {
                case 1:
                    String corredor = JOptionPane.showInputDialog("Digite o corredor da caixa:");
                    String dono = JOptionPane.showInputDialog("Digite o dono da caixa:");
                    int posicao = Integer.parseInt(JOptionPane.showInputDialog("Digite a posição da caixa:"));
                    double peso = Double.parseDouble(JOptionPane.showInputDialog("Digite o peso da caixa:"));

                    Caixa novaCaixa = new Caixa(corredor, posicao, peso, dono);
                    deposito.adicionarCaixa(novaCaixa);
                    JOptionPane.showMessageDialog(null, "Caixa adicionada!");
                    break;
                case 2:
                    String donoRemoveCaixa = JOptionPane.showInputDialog("Digite o dono da caixa a ser removida:");
                    deposito.removerCaixa(donoRemoveCaixa);
                    JOptionPane.showMessageDialog(null, "Caixa removida!");
                    break;
                case 3:
                    String donoBuscaCaixa = JOptionPane.showInputDialog("Digite o dono da caixa a ser encontrada:");
                    int posicaoCaixa = deposito.encontrarCaixa(donoBuscaCaixa);
                    if (posicaoCaixa != -1) {
                        JOptionPane.showMessageDialog(null, "Caixa encontrada na posição: " + posicaoCaixa);
                    } else {
                        JOptionPane.showMessageDialog(null, "Caixa não encontrada.");
                    }
                    break;
                case 4:
                    String donoMudaCaixa = JOptionPane.showInputDialog("Digite o dono da caixa a ser alterada:");
                    String novoCorredor = JOptionPane
                            .showInputDialog("Digite o novo corredor da caixa a ser alterada:");
                    int posicaoAlterada = Integer
                            .parseInt(JOptionPane.showInputDialog("Digite a nova posição da caixa a ser alterada:"));
                    deposito.mudarCorredorPosicao(donoMudaCaixa, novoCorredor, posicaoAlterada);
                    JOptionPane.showMessageDialog(null, "Caixa alterada!");
                    break;
                case 5:
                    StringBuilder caixasPesadas = new StringBuilder("Caixas mais pesadas que 10.0:\n");
                    for (Caixa caixa : deposito.caixasPesadas(10.0)) {
                        caixasPesadas.append(caixa.getDono()).append("-").append(caixa.getPeso()).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, caixasPesadas.toString());
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida.");
            }
        } while (true);
    }
}
