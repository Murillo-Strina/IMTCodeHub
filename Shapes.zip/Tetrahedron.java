public class Tetrahedron extends ThreeDimensionalShape {
    private double edgeLength;

    public Tetrahedron(double edgeLength) {
        this.edgeLength = edgeLength;
    }

    public double calculateVolume() {
        return Math.sqrt(2) / 12 * Math.pow(edgeLength, 3);
    }

    public double calculateTotalSurfaceArea() {
        return Math.sqrt(3) * Math.pow(edgeLength, 2);
    }

    public String getResults() {
        return "=================\nVolume: " + calculateVolume() + "\n=================\nArea total das faces: "
                + calculateTotalSurfaceArea()
                + "\n=================\n";
    }
}