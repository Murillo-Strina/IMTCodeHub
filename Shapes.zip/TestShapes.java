import java.util.Scanner;

public class TestShapes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Insira o raio do circulo:");
        double radius = sc.nextDouble();
        Shape circle = new Circle(radius);
        System.out.println(circle.getResults());

        System.out.println("Insira o lado do quadrado:");
        double sideLength = sc.nextDouble();
        Shape square = new Square(sideLength);
        System.out.println(square.getResults());

        System.out.println("Insira os lados do triangulo:");
        double sideA = sc.nextDouble();
        double sideB = sc.nextDouble();
        double sideC = sc.nextDouble();
        Shape triangle = new Triangle(sideA, sideB, sideC);
        System.out.println(triangle.getResults());

        System.out.println("Insira o lado do cubo:");
        double cubeSideLength = sc.nextDouble();
        Shape cube = new Cube(cubeSideLength);
        System.out.println(cube.getResults());

        System.out.println("Insira o raio da esfera:");
        double sphereRadius = sc.nextDouble();
        Shape sphere = new Sphere(sphereRadius);
        System.out.println(sphere.getResults());

        System.out.println("Insira o lado do tetraedro:");
        double tetrahedronEdgeLength = sc.nextDouble();
        Shape tetrahedron = new Tetrahedron(tetrahedronEdgeLength);
        System.out.println(tetrahedron.getResults());
        sc.close();
    }
}