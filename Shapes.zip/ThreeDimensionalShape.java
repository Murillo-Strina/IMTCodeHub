public abstract class ThreeDimensionalShape implements Shape {
    public abstract double calculateVolume();

    public abstract double calculateTotalSurfaceArea();

    public double calculateArea() {
        return 0;
    }

    public double calculatePerimeter() {
        return 0;
    }
}