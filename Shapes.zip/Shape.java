public interface Shape {
    double calculateArea();

    double calculatePerimeter();

    double calculateVolume();

    double calculateTotalSurfaceArea();

    String getResults();
}
