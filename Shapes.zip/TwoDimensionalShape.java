public abstract class TwoDimensionalShape implements Shape {
    public abstract double calculateArea();

    public abstract double calculatePerimeter();

    public double calculateVolume() {
        return 0;
    }

    public double calculateTotalSurfaceArea() {
        return calculateArea();
    }
}