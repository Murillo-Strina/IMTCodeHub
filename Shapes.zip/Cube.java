public class Cube extends ThreeDimensionalShape {
    private double sideLength;

    public Cube(double sideLength) {
        this.sideLength = sideLength;
    }

    public double calculateVolume() {
        return Math.pow(sideLength, 3);
    }

    public double calculateTotalSurfaceArea() {
        return 6 * Math.pow(sideLength, 2);
    }

    public String getResults() {
        return "=================\nVolume: " + calculateVolume() + "\n=================\nArea total das faces: "
                + calculateTotalSurfaceArea()
                + "\n=================\n";
    }
}